# Dados do Site Copa Transparente

Esses dados são um subconjunto dos dados disponíveis no site Copa Transpatente[1]. A data dos dados é 9/11/2014. Além desses dados, disponibilizamos um arquivo específico de execuções financeiras, do dia 13/11 também extraído do site oficial do governo. A diferença desse arquivo pro original é que os erros de formatação foram corrigidos pros exemplos ficarem sem nenhum erro.

## Tabelas

Instituição
Empreendimento
Licitação
Execução Financeira
Execução Financeira - Corrigido

## Referências

1 - http://www.copatransparente.gov.br/homecopa
